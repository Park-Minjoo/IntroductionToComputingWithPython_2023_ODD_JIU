# Q4
# Write your code here


stats('example.txt')