# Q8
# Write your code here


print(mystery(4))
print(mystery(11))
print(mystery(25))