# Q6

def leap('''Write your code here'''):
    if '''Write your code here'''
        return True
    else:
        '''Write your code here'''

print(leap(2008))
print(leap(1900))
print(leap(2000))