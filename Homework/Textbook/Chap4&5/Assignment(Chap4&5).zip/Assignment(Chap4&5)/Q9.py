# Q9

def inversions('''Write your code here'''):
    '''Write your code here'''
    for i in '''Write your code here''':
        for j in '''Write your code here''':
            if '''Write your code here''':
                '''Write your code here'''
    return '''Write your code here'''

print(inversions('ABBFHDL'))
print(inversions('ABCD'))
print(inversions('DCBA'))