# Q1

def month(number):
    '''Write your code here'''
    return '''Write your code here'''

print(month(1))
print(month(11))