# Q7
# Write your code here


print(fib(0))
print(fib(4))
print(fib(8))