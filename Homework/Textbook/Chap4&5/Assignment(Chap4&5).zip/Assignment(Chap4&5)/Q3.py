# Q3

def crypto('''Write your code here'''):
    file = open(filename)
    '''Write your code here'''
    '''Write your code here'''
    print('''Write your code here''')

crypto('crypto.txt')