# Q5
# Write your code here


print(pay(10, 35))
print(pay(10, 45))
print(pay(10, 61))