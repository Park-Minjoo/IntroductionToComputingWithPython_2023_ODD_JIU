# Q2
# Write your code here


vowelCount('Le Tour de France')