# Q7

# Write your code here


points(0, 0, 1, 1)
points(0, 0, 0, 1)
