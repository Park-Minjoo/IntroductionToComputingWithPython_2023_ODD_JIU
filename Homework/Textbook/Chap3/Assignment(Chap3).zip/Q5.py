# Q5

# Write your code here


pay(10, 35)
pay(10, 45)
