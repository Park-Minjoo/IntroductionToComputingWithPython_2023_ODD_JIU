# Q1

# (a)
print(eval('2 * 3 + 1'))
# (b)
print()
# (c)
print()
# (d)
print()
# (e)
print()