# Q8

# Write your code here


abbreviation('Tuesday')