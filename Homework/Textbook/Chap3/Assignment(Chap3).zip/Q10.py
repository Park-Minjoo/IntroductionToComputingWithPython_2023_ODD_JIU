# Q10

# Write your code here


distance(3)