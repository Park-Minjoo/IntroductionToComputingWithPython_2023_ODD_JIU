# Q6

# Write your code here


prob(1)
prob(2)
