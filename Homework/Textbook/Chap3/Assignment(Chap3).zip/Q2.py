# Q2

# Write your code here