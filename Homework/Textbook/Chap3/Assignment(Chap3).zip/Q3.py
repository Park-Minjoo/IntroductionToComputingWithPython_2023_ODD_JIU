# Q3

# Write your code here