# Q9

# Write your code here


lastF('Albert', 'Camus')