outf = open('MyTripToJIU.txt', 'w')
outf.write('Fill in the blank\n')
outf.write('Fill in the blank\n')
outf.write('Fill in the blank\n')
outf.write('Fill in the blank\n')
outf.write('Fill in the blank\n')
outf.'''Fill the blank'''

inf = open('MyTripToJIU.txt', 'r')
s = '''Fill the blank'''
print(s)
inf.'''Fill the blank'''