inf = '''Fill the blank'''
NumWord = []
for i in range(8):
    '''Fill the blank'''
    '''Fill the blank'''

    NumWord.append('''Fill the blank''')
print(NumWord)
'''Fill the blank'''