inf = '''Fill the blank'''
sm = '''Fill the blank'''
for '''Fill the blank''':
    s = '''Fill the blank'''.strip(" ")
    slist = '''Fill the blank'''
    print('''Fill the blank''')
'''Fill the blank'''