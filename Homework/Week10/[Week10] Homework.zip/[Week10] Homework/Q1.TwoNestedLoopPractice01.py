mul = [10 * [0] for i in range(15)]
# print(mul)

for '''Fill the blank''':
    for '''Fill the blank''':
        mul[i][j] = '''Fill tha blank'''
    print('''Fill the blank''')
print("Done!")