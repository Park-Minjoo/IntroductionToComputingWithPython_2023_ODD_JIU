inf = '''Fill the blank'''
fline = '''Fill the blank'''

for line in fline:
    '''Fill the blank'''
    for i in range('''Fill the blank'''):
        '''Fill the blank'''
    print('''Fill the blank''')
'''Fill the blank'''