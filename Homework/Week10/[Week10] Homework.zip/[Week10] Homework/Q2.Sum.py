inf = '''Fill the blank'''
sm = '''Fill the blank'''
print("All data = ", sm)

for i in '''Fill the blank''' :
    s = sm[i].split(",") ## “,” important
    print(s)
    '''Fill the blank'''
    for j in '''Fill the blank''' :
        sum = '''Fill the blank'''
    print("Average = ", '''Fill the blank''')
    print()
'''Fill the blank'''